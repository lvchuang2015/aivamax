---
type: strategy_plan
public_brand: AIvaMax
pack_id: local-service-leadgen-30d
visibility: client_delivery
status: draft
---

# Strategy Plan

## Growth Hypothesis

The project should validate repeatable demand signals for home cleaning service in Los Angeles before scaling execution volume.

## Stages

| Stage | Days | Output |
| --- | --- | --- |
| Setup | 1-3 | Brief, assets, account roles, risk boundary |
| Test | 4-14 | Content angles and channel signals |
| Capture | 15-24 | Lead signals and response quality |
| Review | 25-30 | Forecast, next-cycle recommendation, delivery report |

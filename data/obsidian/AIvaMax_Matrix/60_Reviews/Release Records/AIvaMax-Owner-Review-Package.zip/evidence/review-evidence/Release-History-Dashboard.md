---
type: release_history_dashboard
public_brand: AIvaMax
visibility: internal_release_record
status: approved
---

# AIvaMax Release History Dashboard

| Field | Value |
| --- | --- |
| Generated at | 2026-06-02T14:09:00+00:00 |
| Record count | 2 |
| Approved | 1 |
| Pending review | 1 |
| Rejected | 0 |
| Latest release | REL-20260602140756 |
| Latest decision | approved |

## Records

| Release ID | Decision | Version | Ready | Client Packs | SHA256 Prefix |
| --- | --- | --- | --- | --- | --- |
| REL-20260602140756 | approved | course-factory-v1 | True | 7 | 8e36071436e8 |
| REL-20260602061539 | pending_review | course-factory-v1 | True | 7 | b226e8ac0db5 |

## Boundary

This dashboard summarizes AIvaMax release records only. It does not include vendor documents, raw crawl storage, or private execution material.
